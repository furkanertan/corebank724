create definer = root@localhost view v_payment_history as
select `p`.`id`                 AS `payment_id`,
       `a`.`id`                 AS `account_id`,
       `u`.`id`                 AS `user_id`,
       `p`.`beneficiary`        AS `beneficiary`,
       `p`.`beneficiary_acc_no` AS `beneficiary_acc_no`,
       `p`.`amount`             AS `amount`,
       `p`.`status`             AS `status`,
       `p`.`reference_no`       AS `reference_no`,
       `p`.`reason_code`        AS `reason_code`,
       `p`.`created_at`         AS `created_at`
from ((`corebank`.`payment` `p` join `corebank`.`account` `a`
       on ((`p`.`account_id` = `a`.`id`))) join `corebank`.`user` `u` on ((`a`.`user_id` = `u`.`id`)));


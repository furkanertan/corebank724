create definer = root@localhost view v_transaction_history as
select `t`.`id`               AS `transaction_id`,
       `a`.`id`               AS `account_id`,
       `u`.`id`               AS `user_id`,
       `t`.`transaction_type` AS `transaction_type`,
       `t`.`amount`           AS `amount`,
       `t`.`source`           AS `source`,
       `t`.`status`           AS `status`,
       `t`.`reason_code`      AS `reason_code`,
       `t`.`created_at`       AS `created_at`
from ((`corebank`.`transaction_history` `t` join `corebank`.`account` `a`
       on ((`t`.`account_id` = `a`.`id`))) join `corebank`.`user` `u` on ((`a`.`user_id` = `u`.`id`)));

